#Display principle, interest rate and the interest amount for first yeae.

pri = int(input("Enter Principle amount of a CD: $"))
mature = int(input("Enter years to mature: "))

if (pri > 100000) and (mature == 5):
  rate = 0.06
elif pri > 50000 and mature ==  10:
  rate = 0.05
elif (pri > 50000) and (mature ==  5):
  rate = 0.04
else:
  rate = 0.02

interest = pri * rate

print("Principle amount of the CD: $",pri)
print("Years of maturity:", mature)
print("Interest rate: ",rate)
print("Interest amount of the first year: $",interest)
#Display the number of tickets, price per ticket and the total cost

ticket = int(input("Enter number of Tickets: "))

if ticket >= 25:
  price = 50.00
elif ticket >= 10:
  price = 60.00
elif ticket >= 5:
  price = 70
else:
  price = 75

total = price * ticket

print("Number of Tickets:",ticket)
print("Price per Ticket: $",price)
print("Total Cost: $",total)
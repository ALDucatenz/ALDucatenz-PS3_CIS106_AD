#Calculate tax at 7%.  Display the extended price, tax amount and total. 

qty = int(input("Enter Quantity: "))

if qty > 10000:
  price = 10
elif qty > 5000:
  price =20
elif 5000 > qty:
  price =30

ext = qty * price
tax = ext * 0.07
total = ext + tax

print("Extended price: $",ext)
print("Tax Amount: $",tax)
print("Total Amount: $",total)
#Display employee last name and bonus.

name = input("Enter Lastname: ")
salary = float(input("Enter Salary: $"))
lvl = int(input("Enter Job Level: "))

if lvl >= 10:
  rate = .25
elif lvl >= 5:
  rate =.2
else:
  rate = .1

bonus = rate * salary

print(name,"bonus: $",bonus)
#Display the part number, cost per unit and total cost

partno = int(input("Enter Part Number: "))
qty = input("Enter Quantity: ")

if partno == 10 or partno == 55:
  unitprice = 1.00
elif partno == 99:
  unitprice = 2.00
elif partno == 80 or partno == 70:
  unitprice = 3.00
else:
  unitprice = 5.00

total = unitprice * float(qty)

print("Part number: ",partno)
print("Quantity: ",qty)
print("Unit price: $",unitprice)
print("Total Amount: $",total)